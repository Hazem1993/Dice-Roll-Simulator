package com.example.dicesimulator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnExit :Button = findViewById(R.id.btnExit)
        val btnRoll :Button = findViewById(R.id.btnRoll)
        val txtView :TextView = findViewById(R.id.txtView)
        val rolldice = Dice()
        btnRoll.setOnClickListener{
            txtView.text=rolldice.roll().toString()
            Toast.makeText(this, "Dice Rolled", Toast.LENGTH_SHORT).show()
        }
        btnExit.setOnClickListener{
            finish()
        }
    }

}

class Dice {

    fun roll(): Int {
        return (1..6).random()
    }
}
